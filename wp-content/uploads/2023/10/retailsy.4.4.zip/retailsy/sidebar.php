<?php if ( ! is_active_sidebar( 'retailsy-sidebar-primary' ) ) {	return; } ?>
<div id="st-secondary-content" class="col-md-6 col-lg-4">
	<section class="sidebar">
		<?php dynamic_sidebar('retailsy-sidebar-primary'); ?>
	</section>
</div>