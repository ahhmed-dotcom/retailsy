<?php if ( ! is_active_sidebar( 'retailsy-woocommerce-sidebar' ) ) {	return; } ?>
<div id="st-secondary-content" class="col-lg-3 mb-lg-0 mb-4 product-sidebar-column">
	<section class="sidebar">
		<?php dynamic_sidebar('retailsy-woocommerce-sidebar'); ?>
	</section>
</div>